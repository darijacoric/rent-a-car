﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentACar.ViewModels
{
    public class EntityStatusView
    {
        public string StatusName { get; set; }
        public int StatusValue { get; set; }
        public bool Checked { get; set; }
    }
}