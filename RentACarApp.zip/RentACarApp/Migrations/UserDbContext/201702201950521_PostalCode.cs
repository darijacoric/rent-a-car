namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PostalCode : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Users", "PostalCode", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Users", "PostalCode", c => c.Int(nullable: false));
        }
    }
}
