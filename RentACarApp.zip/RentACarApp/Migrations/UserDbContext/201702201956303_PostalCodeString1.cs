namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PostalCodeString1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Users", "PostalCode", c => c.String(maxLength: 16));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Users", "PostalCode", c => c.String());
        }
    }
}
