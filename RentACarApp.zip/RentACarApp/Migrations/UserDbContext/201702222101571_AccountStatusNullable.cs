namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AccountStatusNullable : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Users", "AccountStatus", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Users", "AccountStatus", c => c.Int(nullable: false));
        }
    }
}
