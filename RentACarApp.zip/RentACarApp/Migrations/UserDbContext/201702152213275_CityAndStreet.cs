namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CityAndStreet : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "City", c => c.String(maxLength: 30));
            AddColumn("dbo.Users", "StreetName", c => c.String(maxLength: 40));
            AddColumn("dbo.Users", "State", c => c.String(maxLength: 30));
            DropColumn("dbo.Users", "Address");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Users", "Address", c => c.String());
            DropColumn("dbo.Users", "State");
            DropColumn("dbo.Users", "StreetName");
            DropColumn("dbo.Users", "City");
        }
    }
}
