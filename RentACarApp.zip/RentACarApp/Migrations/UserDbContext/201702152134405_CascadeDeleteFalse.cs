namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CascadeDeleteFalse : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.CreditCards", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserClaims", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserLogins", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserRoles", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserRoles", "RoleId", "dbo.Roles");
            AddForeignKey("dbo.CreditCards", "UserId", "dbo.Users", "Id");
            AddForeignKey("dbo.UserClaims", "UserId", "dbo.Users", "Id");
            AddForeignKey("dbo.UserLogins", "UserId", "dbo.Users", "Id");
            AddForeignKey("dbo.UserRoles", "UserId", "dbo.Users", "Id");
            AddForeignKey("dbo.UserRoles", "RoleId", "dbo.Roles", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.UserRoles", "RoleId", "dbo.Roles");
            DropForeignKey("dbo.UserRoles", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserLogins", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserClaims", "UserId", "dbo.Users");
            DropForeignKey("dbo.CreditCards", "UserId", "dbo.Users");
            AddForeignKey("dbo.UserRoles", "RoleId", "dbo.Roles", "Id", cascadeDelete: true);
            AddForeignKey("dbo.UserRoles", "UserId", "dbo.Users", "Id", cascadeDelete: true);
            AddForeignKey("dbo.UserLogins", "UserId", "dbo.Users", "Id", cascadeDelete: true);
            AddForeignKey("dbo.UserClaims", "UserId", "dbo.Users", "Id", cascadeDelete: true);
            AddForeignKey("dbo.CreditCards", "UserId", "dbo.Users", "Id", cascadeDelete: true);
        }
    }
}
