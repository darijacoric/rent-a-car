namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreaditCardExpiration : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.CreditCards", "ExpirationDate", c => c.DateTime(nullable: false));
            AlterColumn("dbo.CreditCards", "CardNumber", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.CreditCards", "CardNumber", c => c.String());
            DropColumn("dbo.CreditCards", "ExpirationDate");
        }
    }
}
