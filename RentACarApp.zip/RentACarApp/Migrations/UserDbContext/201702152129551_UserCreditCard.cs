namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UserCreditCard : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Users", "CardId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Users", "CardId", c => c.Int());
        }
    }
}
