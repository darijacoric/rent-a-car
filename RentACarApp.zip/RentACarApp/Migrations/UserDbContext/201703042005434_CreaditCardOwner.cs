namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreaditCardOwner : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.CreditCards", "OwnerFirstName", c => c.String(nullable: false, maxLength: 30));
            AddColumn("dbo.CreditCards", "OwnerLastName", c => c.String(nullable: false, maxLength: 30));
        }
        
        public override void Down()
        {
            DropColumn("dbo.CreditCards", "OwnerLastName");
            DropColumn("dbo.CreditCards", "OwnerFirstName");
        }
    }
}
