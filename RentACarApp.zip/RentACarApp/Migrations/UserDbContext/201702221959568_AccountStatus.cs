namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AccountStatus : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "AccountStatus", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Users", "AccountStatus");
        }
    }
}
