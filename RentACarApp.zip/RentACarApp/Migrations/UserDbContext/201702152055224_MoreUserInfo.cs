namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MoreUserInfo : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CreditCards",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        CardNumber = c.String(),
                        UserId = c.Int(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Users", t => t.UserId, cascadeDelete: false)
                .Index(t => t.UserId);
            
            AddColumn("dbo.Users", "PostalCode", c => c.Int(nullable: false));
            AddColumn("dbo.Users", "CardId", c => c.Int());
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CreditCards", "UserId", "dbo.Users");
            DropIndex("dbo.CreditCards", new[] { "UserId" });
            DropColumn("dbo.Users", "CardId");
            DropColumn("dbo.Users", "PostalCode");
            DropTable("dbo.CreditCards");
        }
    }
}
