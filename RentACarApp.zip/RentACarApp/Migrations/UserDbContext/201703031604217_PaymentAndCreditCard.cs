namespace RentACar.Migrations.UserDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PaymentAndCreditCard : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.PaymentTypes",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Description = c.String(),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.CreditCards", "PaymentTypeId", c => c.Int(nullable: false));
            CreateIndex("dbo.CreditCards", "PaymentTypeId");
            AddForeignKey("dbo.CreditCards", "PaymentTypeId", "dbo.PaymentTypes", "ID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CreditCards", "PaymentTypeId", "dbo.PaymentTypes");
            DropIndex("dbo.CreditCards", new[] { "PaymentTypeId" });
            DropColumn("dbo.CreditCards", "PaymentTypeId");
            DropTable("dbo.PaymentTypes");
        }
    }
}
