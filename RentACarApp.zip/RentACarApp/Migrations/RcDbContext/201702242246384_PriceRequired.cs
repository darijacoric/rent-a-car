namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PriceRequired : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Vehicle", "AcquiredDate", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Vehicle", "DayPrice", c => c.Double(nullable: false));
            AlterColumn("dbo.Vehicle", "ProductionDate", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Vehicle", "ProductionDate", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Vehicle", "DayPrice", c => c.Double());
            DropColumn("dbo.Vehicle", "AcquiredDate");
        }
    }
}
