namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EquipmentNameRequired : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Equipment", "Name", c => c.String(nullable: false, maxLength: 32));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Equipment", "Name", c => c.String(maxLength: 32));
        }
    }
}
