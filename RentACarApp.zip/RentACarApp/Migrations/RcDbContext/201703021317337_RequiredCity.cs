namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RequiredCity : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.VehicleLocation", "City", c => c.String(nullable: false, maxLength: 32));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.VehicleLocation", "City", c => c.String(maxLength: 32));
        }
    }
}
