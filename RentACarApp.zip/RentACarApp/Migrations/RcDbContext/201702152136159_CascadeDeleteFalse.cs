namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CascadeDeleteFalse : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.CarEquipment", "EquipmentID", "dbo.Equipment");
            DropForeignKey("dbo.CarEquipment", "VehicleID", "dbo.Vehicle");
            AddForeignKey("dbo.CarEquipment", "EquipmentID", "dbo.Equipment", "ID");
            AddForeignKey("dbo.CarEquipment", "VehicleID", "dbo.Vehicle", "ID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CarEquipment", "VehicleID", "dbo.Vehicle");
            DropForeignKey("dbo.CarEquipment", "EquipmentID", "dbo.Equipment");
            AddForeignKey("dbo.CarEquipment", "VehicleID", "dbo.Vehicle", "ID", cascadeDelete: true);
            AddForeignKey("dbo.CarEquipment", "EquipmentID", "dbo.Equipment", "ID", cascadeDelete: true);
        }
    }
}
