namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PhotosAndEquipmentDescription : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.VehiclePhoto", "VehicleID", "dbo.Vehicle");
            DropIndex("dbo.VehiclePhoto", new[] { "VehicleID" });
            CreateTable(
                "dbo.Photo",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        ItemID = c.Int(nullable: false),
                        ItemType = c.String(),
                        PictureName = c.String(),
                        Content = c.Binary(),
                        PictureType = c.String(),
                        ProfilePicture = c.Int(),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.Equipment", "Description", c => c.String(maxLength: 512));
            AlterColumn("dbo.Equipment", "Name", c => c.String(maxLength: 32));
            DropTable("dbo.VehiclePhoto");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.VehiclePhoto",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        VehicleID = c.Int(nullable: false),
                        PictureName = c.String(),
                        Content = c.Binary(),
                        PictureType = c.Int(),
                        ProfilePicture = c.Int(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AlterColumn("dbo.Equipment", "Name", c => c.String());
            DropColumn("dbo.Equipment", "Description");
            DropTable("dbo.Photo");
            CreateIndex("dbo.VehiclePhoto", "VehicleID");
            AddForeignKey("dbo.VehiclePhoto", "VehicleID", "dbo.Vehicle", "ID");
        }
    }
}
