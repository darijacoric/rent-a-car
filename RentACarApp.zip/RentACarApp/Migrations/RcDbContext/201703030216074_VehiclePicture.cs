namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class VehiclePicture : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Vehicle", "Picture", c => c.Binary());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Vehicle", "Picture");
        }
    }
}
