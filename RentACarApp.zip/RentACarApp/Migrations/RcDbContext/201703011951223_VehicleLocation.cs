namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class VehicleLocation : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.VehicleLocation",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Place = c.String(nullable: false, maxLength: 32),
                        City = c.String(maxLength: 32),
                        LocationPicture = c.Binary(),
                        Description = c.String(maxLength: 512),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.VehicleLocation");
        }
    }
}
