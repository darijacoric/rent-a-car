namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AcquiredDate : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Vehicle", "ProductionDate");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Vehicle", "ProductionDate", c => c.DateTime());
        }
    }
}
