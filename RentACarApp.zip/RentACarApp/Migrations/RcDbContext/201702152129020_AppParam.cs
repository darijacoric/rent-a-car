namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AppParam : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AppParam",
                c => new
                    {
                        ParamCode = c.String(nullable: false, maxLength: 128),
                        ParamDescription = c.String(),
                        Status = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ParamCode);
            
            CreateTable(
                "dbo.AppParamValue",
                c => new
                    {
                        ID = c.Int(nullable: false),
                        ParamCode = c.String(maxLength: 128),
                        ParamValue = c.String(),
                        Status = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.AppParam", t => t.ParamCode)
                .Index(t => t.ParamCode);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AppParamValue", "ParamCode", "dbo.AppParam");
            DropIndex("dbo.AppParamValue", new[] { "ParamCode" });
            DropTable("dbo.AppParamValue");
            DropTable("dbo.AppParam");
        }
    }
}
