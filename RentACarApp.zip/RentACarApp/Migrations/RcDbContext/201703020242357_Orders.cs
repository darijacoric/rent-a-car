namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Orders : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Order",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        OrderNumber = c.Int(nullable: false),
                        RecvLocationId = c.Int(nullable: false),
                        RecvTime = c.DateTime(nullable: false),
                        DestLocationId = c.Int(nullable: false),
                        DestTime = c.DateTime(nullable: false),
                        VehicleId = c.Int(nullable: false),
                        UserId = c.Int(nullable: false),
                        TotalPrice = c.Double(nullable: false),
                        PaymentTypeId = c.Int(nullable: false),
                        CreditCardId = c.Int(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.VehicleLocation", t => t.DestLocationId)
                .ForeignKey("dbo.VehicleLocation", t => t.RecvLocationId)
                .ForeignKey("dbo.Vehicle", t => t.VehicleId)
                .Index(t => t.RecvLocationId)
                .Index(t => t.DestLocationId)
                .Index(t => t.VehicleId);
            
            CreateTable(
                "dbo.PaymentType",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Description = c.String(),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.Vehicle", "GasPerKm", c => c.Double(nullable: false));
            DropColumn("dbo.Vehicle", "Order");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Vehicle", "Order", c => c.Int());
            DropForeignKey("dbo.Order", "VehicleId", "dbo.Vehicle");
            DropForeignKey("dbo.Order", "RecvLocationId", "dbo.VehicleLocation");
            DropForeignKey("dbo.Order", "DestLocationId", "dbo.VehicleLocation");
            DropIndex("dbo.Order", new[] { "VehicleId" });
            DropIndex("dbo.Order", new[] { "DestLocationId" });
            DropIndex("dbo.Order", new[] { "RecvLocationId" });
            DropColumn("dbo.Vehicle", "GasPerKm");
            DropTable("dbo.PaymentType");
            DropTable("dbo.Order");
        }
    }
}
