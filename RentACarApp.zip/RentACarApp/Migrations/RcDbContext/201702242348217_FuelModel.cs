namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FuelModel : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Fuel",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        FuelName = c.String(),
                        PricePerLiter = c.Double(),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.Vehicle", "FuelId", c => c.Int());
            CreateIndex("dbo.Vehicle", "FuelId");
            AddForeignKey("dbo.Vehicle", "FuelId", "dbo.Fuel", "ID");
            DropColumn("dbo.Vehicle", "Fuel");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Vehicle", "Fuel", c => c.Int(nullable: false));
            DropForeignKey("dbo.Vehicle", "FuelId", "dbo.Fuel");
            DropIndex("dbo.Vehicle", new[] { "FuelId" });
            DropColumn("dbo.Vehicle", "FuelId");
            DropTable("dbo.Fuel");
        }
    }
}
