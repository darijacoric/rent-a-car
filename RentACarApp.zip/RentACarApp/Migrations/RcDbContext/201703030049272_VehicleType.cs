namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class VehicleType : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Vehicle", "VehicleType", c => c.String(nullable: false));
            AddColumn("dbo.Vehicle", "Airbags", c => c.Int(nullable: false));
            AddColumn("dbo.Vehicle", "ModelYear", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Vehicle", "ModelYear");
            DropColumn("dbo.Vehicle", "Airbags");
            DropColumn("dbo.Vehicle", "VehicleType");
        }
    }
}
