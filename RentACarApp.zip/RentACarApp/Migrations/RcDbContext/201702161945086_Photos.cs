namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Photos : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.VehiclePhoto",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        VehicleID = c.Int(nullable: false),
                        PictureName = c.String(),
                        Content = c.Binary(),
                        PictureType = c.Int(),
                        ProfilePicture = c.Int(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Vehicle", t => t.VehicleID)
                .Index(t => t.VehicleID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.VehiclePhoto", "VehicleID", "dbo.Vehicle");
            DropIndex("dbo.VehiclePhoto", new[] { "VehicleID" });
            DropTable("dbo.VehiclePhoto");
        }
    }
}
