namespace RentACar.Migrations.RcDbContext
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialDatabase : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CarEquipment",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        VehicleID = c.Int(nullable: false),
                        EquipmentID = c.Int(nullable: false),
                        CombinationPrice = c.Double(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Equipment", t => t.EquipmentID, cascadeDelete: true)
                .ForeignKey("dbo.Vehicle", t => t.VehicleID, cascadeDelete: true)
                .Index(t => t.VehicleID)
                .Index(t => t.EquipmentID);
            
            CreateTable(
                "dbo.Equipment",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Price = c.Double(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Vehicle",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Brand = c.String(nullable: false),
                        BrandType = c.String(nullable: false),
                        HorsePower = c.Int(),
                        DoorsCount = c.Int(),
                        Registration = c.String(nullable: false),
                        RegistrationExpire = c.DateTime(nullable: false),
                        Free = c.Int(),
                        SeatCount = c.Int(),
                        Order = c.Int(),
                        Fuel = c.Int(nullable: false),
                        Mileage = c.Double(),
                        DayPrice = c.Double(),
                        ProductionDate = c.DateTime(nullable: false),
                        Status = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                        ModifiedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CarEquipment", "VehicleID", "dbo.Vehicle");
            DropForeignKey("dbo.CarEquipment", "EquipmentID", "dbo.Equipment");
            DropIndex("dbo.CarEquipment", new[] { "EquipmentID" });
            DropIndex("dbo.CarEquipment", new[] { "VehicleID" });
            DropTable("dbo.Vehicle");
            DropTable("dbo.Equipment");
            DropTable("dbo.CarEquipment");
        }
    }
}
