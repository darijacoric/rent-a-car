﻿
//$(document).ready(function () {
//    $(function () {
//        try {
//            $.validator.addMethod('date',
//            function (value, element) {
//                if (this.optional(element)) {
//                    return true;
//                }
//                var ok = true;
//                try {
//                    ok = moment(value, "YYYY-MM-DD", true).isValid();
//                } catch (err) {
//                    ok = false;
//                }
//                return ok;
//            });
//        } catch (e) { }
//    });
//})
